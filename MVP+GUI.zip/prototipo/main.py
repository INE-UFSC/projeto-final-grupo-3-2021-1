from sistema import Sistema


"""Inicia Sistema do jogo"""
if __name__ == '__main__':
    Sistema()
