# Quebra-Ossos
Repositório do trabalho final de POO II
<br><b>Equipe:</b> Anthon Gretter, Mauricio Konrath, Nicolas Elias, Rian Serena</br>

## [Link do repositorio antigo](https://github.com/anthongretter/quebra-ossos)

### Como foi implementado
Implementamos a maior parte via live share do vscode
<br>Temos nossa participação via [discord](https://discord.gg/WZ3G9PAzRp) (para caso os professores queiram visualizar nossa discussão)</br>

### Bibliotecas ultilizadas
* pygame
* time

### Comandos para jogar
* Pular    -> ARROW UP
* Esquerda -> ARROW LEFT
* Direita  -> ARROW RIGHT
