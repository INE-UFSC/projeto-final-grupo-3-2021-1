Documente aqui a interface gráfica definida para o jogo. Assim como no UML, a GUI deve ter mudanças durante a implementação, mas isso é natural. 

Coloque aqui as principais telas do jogo, como tela de início e fim de jogo, jogabilidade, pausa, menus etc. Indique também (nas figuras ou textualmente) os mecanismos previstos para entrada pelos usuários: botões, teclas de teclado, zonas de swipe etc.
